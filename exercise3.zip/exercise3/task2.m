%Assignment 3
%Task 2
%Convertion of Cartesian Coordinates to Spherical Coordinates.
% xber = (3782970.10 902154.92 5038375.59) m
clc;
clear all;
format long;
x1=3782970.10; %m
y1=902154.92;  %m
z1=5038375.59; %m
%%Convertion of Cartesian Coordinates to Spherical Coordinates 1.
[r1,lambda1,phi1]=car2sph(x1,y1,z1);

% Convertion of Spherical Coordinates to Cartesian Coordinates 1.

[x2,y2,z2]=sph2car(r1,lambda1,phi1);

%Convertion of Cartesian Coordinates to Spherical Coordinates 2.

[r2,lambda2,phi2]=car2sph(x2,y2,z2);


%Differences between cartesian coordinates 
dx = x1 - x2;
dy = y1 - y2;
dz = z1 - z2;


%Differences between Spherical Coordinates
drad = r1 - r2;
dlam = lambda1 - lambda2;
dlam=rad2deg(dlam);
dphi = phi1 - phi2;
dphi=rad2deg(dphi);




