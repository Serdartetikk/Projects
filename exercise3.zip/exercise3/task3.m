%Assignment 3
%Task 3
%xber = (3782970.10 902154.92 5038375.59) m
% Task3.a
clc;clear all;close all;
format long;
X1=3782970.10;
Y1=902154.92;
Z1=5038375.59;
% 1--- BESSEL
% 2----WGS 84
% 3----GRS 80
[B1,L1,h1]=car2geo(X1,Y1,Z1,3); %GRS 80
B1=rad2deg(B1); %degree
L1=rad2deg(L1); %degree

%Convert from Geodetic to Cartesian Coordinate

ellipsoid = referenceEllipsoid('GRS 80');
[X2,Y2,Z2] = geodetic2ecef(ellipsoid,B1,L1,h1,"degrees");
Xdiff_car=X2-X1;%the differences between two cartesian coordinates
Ydiff_car=Y2-Y1;%the differences between two cartesian coordinates
Zdiff_car=Z2-Z1;%the differences between two cartesian coordinates

[B2,L2,h2]=car2geo(X2,Y2,Z2,3);% converts again from cartesian to the geodetic coordinates
B2=rad2deg(B2);
L2=rad2deg(L2);
Bdiff_geo=B2-B1; %differences between two geodetic coordinates
Ldiff_geo=L2-L1; %differences between two geodetic coordinates
hdiff_geo=h2-h1; %differences between two geodetic coordinates
% Result; there is no difference between the geodetic coordinates
%Task3.b
[B_GRS80,L_GRS80,h_GRS80]=car2geo(X1,Y1,Z1,3); %converts cartesians coordinates to geodetic refering to GRS80
B_GRS80=rad2deg(B_GRS80);%degree
L_GRS80=rad2deg(L_GRS80);%degree
[B_WGS84,L_WGS84,h_WGS84]=car2geo(X1,Y1,Z1,2); %converts cartesians coordinates to geodetic refering to WGS84
B_WGS84=rad2deg(B_WGS84);%degree
L_WGS84=rad2deg(L_WGS84);%degree
[B_BES,L_BES,h_BES]=car2geo(X1,Y1,Z1,1); %converts cartesians coordinates to geodetic refering to BESSEL
B_BES=rad2deg(B_BES);%degree
L_BES=rad2deg(L_BES);%degree
%Ratios GRS80-WGS84
diff_B_GRS80_WGS_84 = ((B_WGS84-B_GRS80)/B_GRS80)*100;
diff_L_GRS80_WGS_84 = ((L_WGS84-L_GRS80)/L_GRS80)*100;
diff_h_GRS80_WGS_84 = ((h_WGS84-h_GRS80)/h_GRS80)*100;

%Ratios GRS80-BESSEL
diff_B_GRS80_BES= ((B_BES-B_GRS80)/B_GRS80)*100;
diff_L_GRS80_BES= ((L_BES-L_GRS80)/L_GRS80)*100;
diff_h_GRS80_BES= ((h_BES-h_GRS80)/h_GRS80)*100;
