function [x,y,z] = sph2car(r,lambda,phi)
x=r*cos(lambda)*cos(phi);
y=r*sin(lambda)*cos(phi);
z=r*sin(phi);

end