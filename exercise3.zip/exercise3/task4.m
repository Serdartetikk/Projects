
%TASK 4
clc;clear all;

X1=3782970.10;
Y1=902154.92;
Z1=5038375.59;
% GEODETIC COORDINATES IN DIFFERENT REFERANCE ELLIPSOID
[B1,L1,h1]=car2geo(X1,Y1,Z1,1); %BESSEL
B1=rad2deg(B1);L1=rad2deg(L1);% degree

[B2,L2,h2]=car2geo(X1,Y1,Z1,2); %WGS 84
B2=rad2deg(B2);L2=rad2deg(L2); %degree

[B3,L3,h3]=car2geo(X1,Y1,Z1,3); %GRS 80
B3=rad2deg(B3);L3=rad2deg(L3); %degree

% SPHERICAL COORDINATES 
[r1,lambda1,phi1]=car2sph(X1,Y1,Z1);
h4=r1-6371;
lambda1=rad2deg(lambda1);
phi1=rad2deg(phi1);

% Differences
dB_bessel=B1-phi1;%sph-Bessel
dL_bessel=L1-lambda1;
dB_wgs=B2-phi1; %sph-wgs84
dL_wgs=L2-lambda1;
dB_grs=B3-phi1;
dL_grs=L3-lambda1; %sph-grs80

%Compare
dB_bessel/phi1;
dB_wgs/phi1;
dB_grs/phi1;
% for latitude, BESSEL is locally closest to the sphere;
% for longitude, all are same to the sphere
%for h height, all of them are far away from sphere, but WGS 84 is much closer