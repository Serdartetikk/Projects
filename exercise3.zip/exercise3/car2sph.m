function [r,lambda,phi]=car2sph(x,y,z)
    r = sqrt(x^2 + y^2 + z^2);
    lambda = atan2(y,x);
    phi = atan2(z , (sqrt(x^2+y^2)));
end