function [B,L,h] = car2geo(x,y,z,ellipsoid)
% Converts from Cartesian to Geodetic Coordinates

% input :
% x:  x coordinate [m]
% y:  y coordinate [m]
% z:  z coordinate [m]

% output :
% B: ellipsoidal latitude [rad]
% L: ellipsoidal longitude [rad]
% h: ellipsoidal height [m]

switch ellipsoid
    case 1 % BESSEL
        a = 6377397.155;
        f = 1/299.1528128;
        e2 = 2 * f - f ^ 2;
        ep2 = e2 / (1 - e2); % square of second eccentricity
        b = a * (1 - f); % semi-minor axis
        L = atan2(y,x); % geodetic longitude
        p = sqrt(abs(x).^2+abs(y).^2);% distance from z-axis
        beta = atan2(z, (1 - f) * p); % parametric latitude start value
        B = atan2(z + b * ep2 * sin(beta).^3,...
        p - a * e2 * cos(beta).^3);
        betaNew = atan2((1 - f)*sin(B), cos(B));
        i = 0;
        while any(beta(:) ~= betaNew(:)) && i < 5 
            beta = betaNew;
            B = atan2(z + b * ep2 * sin(beta).^3,... 
            p - a * e2 * cos(beta).^3); betaNew = atan2((1 - f)*sin(B), cos(B));
            i=i+1;
        end
        sinB = sin(B);
        N = a ./ sqrt(1 - e2 * sinB.^2);
        h = p .* cos(B) + (z + e2 * N .* sinB) .* sinB - N;
    case 2 %WGS 84
        a = 6378137;
        f = 1/298.257223563;

        e2 = 2 * f - f ^ 2;
        ep2 = e2 / (1 - e2); % square of second eccentricity
        b = a * (1 - f); % semi-minor axis
        L = atan2(y,x); % geodetic longitude
        p = sqrt(abs(x).^2+abs(y).^2);% distance from z-axis
        beta = atan2(z, (1 - f) * p); % parametric latitude start value
        B = atan2(z + b * ep2 * sin(beta).^3,...
        p - a * e2 * cos(beta).^3);
        betaNew = atan2((1 - f)*sin(B), cos(B));
        i = 0;
        while any(beta(:) ~= betaNew(:)) && i < 5 
            beta = betaNew;
            B = atan2(z + b * ep2 * sin(beta).^3,... 
            p - a * e2 * cos(beta).^3); betaNew = atan2((1 - f)*sin(B), cos(B));
            i=i+1;
        end
        sinB = sin(B);
        N = a ./ sqrt(1 - e2 * sinB.^2);
        h = p .* cos(B) + (z + e2 * N .* sinB) .* sinB - N;
    case 3 %GRS 80
        a = 6378137;
        f = 1/298.257222101;

        e2 = 2 * f - f ^ 2;
        ep2 = e2 / (1 - e2); % square of second eccentricity
        b = a * (1 - f); % semi-minor axis
        L = atan2(y,x); % geodetic longitude
        p = sqrt(abs(x).^2+abs(y).^2);% distance from z-axis
        beta = atan2(z, (1 - f) * p); % parametric latitude start value
        B = atan2(z + b * ep2 * sin(beta).^3,...
        p - a * e2 * cos(beta).^3);
        betaNew = atan2((1 - f)*sin(B), cos(B));
        i = 0;
        while any(beta(:) ~= betaNew(:)) && i < 5 
            beta = betaNew;
            B = atan2(z + b * ep2 * sin(beta).^3,... 
            p - a * e2 * cos(beta).^3); betaNew = atan2((1 - f)*sin(B), cos(B));
            i=i+1;
        end
        sinB = sin(B);
        N = a ./ sqrt(1 - e2 * sinB.^2);
        h = p .* cos(B) + (z + e2 * N .* sinB) .* sinB - N;
    otherwise
        disp('Error');
end
end